# Skyline Hotel – Real Android APK

This project builds a **real Android APK** (not a renamed zip).

## How to get the APK (easiest way)

1. Create a new GitHub repository
2. Upload **everything** in this folder to the repository
3. Go to the **Actions** tab
4. Click **Build Real Android APK** → **Run workflow**
5. Wait 3–6 minutes
6. Download the artifact called **SkylineHotel-APK**
7. Transfer the `.apk` file to your phone and install it  
   (you may need to allow "Install from unknown sources")

## What you get

- A real `.apk` file that Android can install
- The full 10-floor hotel game
- Mobile controls already included

## Notes

- This builds a **debug** APK (good for testing)
- For Google Play Store you will later need a signed release APK
- The game still needs internet the first time (it loads Three.js from a CDN)

## Project structure

```
skyline-android/
├── www/                     ← the actual game
├── package.json
├── capacitor.config.json
└── .github/workflows/build-apk.yml
```
