# The Last Floor

A mobile-first horror hotel prototype made with Godot 4.7.2.

## Gameplay prototype

- 6 helicopter parts
- Roof helicopter objective
- Mobile joystick + touch look
- Sprint/stamina
- Two-door store layout
- 8 monster prototypes:
  1. The Follower
  2. The Stare Beast
  3. The Hungry Zombie
  4. The Warning Animal
  5. The Black-Dress Girl
  6. The Toy Girl
  7. The Crying Mouth
  8. The Room Between

## Build

Push this repository to GitHub, then open **Actions** and run **Build Android APK**.
The finished APK will appear under the workflow's **Artifacts** section.

This is a playable prototype foundation: art, audio, animation, menus, save system, networking, and a larger hotel can be added on top.
