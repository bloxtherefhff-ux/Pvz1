extends Node3D

const FLOOR_Y := 0.0
const PLAYER_HEIGHT := 1.75
const HOTEL_W := 46.0
const HOTEL_D := 70.0
const ROOM_W := 8.0
const ROOM_D := 10.0
const WALL_T := 0.35

var player: CharacterBody3D
var camera: Camera3D
var flashlight: SpotLight3D
var ui: CanvasLayer
var status_label: Label
var objective_label: Label
var interact_button: Button
var sprint_button: Button
var joystick_base: ColorRect
var joystick_knob: ColorRect

var yaw := 0.0
var pitch := -0.08
var touch_look_id := -1
var joy_touch_id := -1
var joy_vector := Vector2.ZERO
var last_touch := Vector2.ZERO
var health := 100.0
var stamina := 100.0
var helicopter_parts := 0
var total_parts := 6
var interact_target: Node = null
var horror_clock := 0.0
var message_clock := 0.0
var objective := "Find 6 helicopter parts and repair the helicopter on the roof."

var monsters: Array[Dictionary] = []
var items: Array[Dictionary] = []
var stores: Array[Dictionary] = []

func _ready() -> void:
	_build_world()
	_build_player()
	_build_ui()
	_spawn_items()
	_spawn_monsters()
	_show_message("The hotel is silent. Find the helicopter parts.", 5.0)

func _process(delta: float) -> void:
	horror_clock += delta
	message_clock = maxf(0.0, message_clock - delta)
	_update_player(delta)
	_update_monsters(delta)
	_update_items()
	_update_ui()
	_update_lighting()

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			var p := event.position
			if p.x < get_viewport().size.x * 0.42 and p.y > get_viewport().size.y * 0.50:
				joy_touch_id = event.index
				_update_joystick(p)
			elif p.x > get_viewport().size.x * 0.45:
				touch_look_id = event.index
				last_touch = p
		else:
			if event.index == joy_touch_id:
				joy_touch_id = -1
				joy_vector = Vector2.ZERO
				_update_joystick(Vector2.ZERO)
			if event.index == touch_look_id:
				touch_look_id = -1
	elif event is InputEventScreenDrag:
		if event.index == joy_touch_id:
			_update_joystick(event.position)
		elif event.index == touch_look_id:
			var d := event.position - last_touch
			last_touch = event.position
			yaw -= d.x * 0.004
			pitch = clampf(pitch - d.y * 0.003, -1.2, 1.0)
			_apply_camera_rotation()
	elif event is InputEventKey and event.pressed and event.keycode == KEY_E:
		_do_interact()

func _update_joystick(pos: Vector2) -> void:
	if pos == Vector2.ZERO:
		joy_vector = Vector2.ZERO
		joystick_knob.position = joystick_base.position + joystick_base.size * 0.5 - joystick_knob.size * 0.5
		return
	var center := joystick_base.position + joystick_base.size * 0.5
	var v := pos - center
	var radius := joystick_base.size.x * 0.5
	if v.length() > radius:
		v = v.normalized() * radius
	joy_vector = v / radius
	joystick_knob.position = center + v - joystick_knob.size * 0.5

func _update_player(delta: float) -> void:
	var input_vec := Vector2(
		Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
		Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
	)
	input_vec += joy_vector
	input_vec = input_vec.limit_length(1.0)
	var sprinting := Input.is_action_pressed("sprint") or sprint_button.button_pressed
	if sprinting and input_vec.length() > 0.1 and stamina > 0.0:
		stamina = maxf(0.0, stamina - 28.0 * delta)
	else:
		stamina = minf(100.0, stamina + 18.0 * delta)
	var speed := 3.1 if not sprinting else 5.0
	var basis := Basis(Vector3.UP, yaw)
	var dir := (basis * Vector3(input_vec.x, 0, input_vec.y)).normalized()
	player.velocity.x = dir.x * speed
	player.velocity.z = dir.z * speed
	player.velocity.y = -1.5
	player.move_and_slide()
	player.global_position.x = clampf(player.global_position.x, -HOTEL_W/2.0 + 1.0, HOTEL_W/2.0 - 1.0)
	player.global_position.z = clampf(player.global_position.z, -HOTEL_D/2.0 + 1.0, HOTEL_D/2.0 - 1.0)

func _apply_camera_rotation() -> void:
	player.rotation.y = yaw
	camera.rotation.x = pitch

func _build_world() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.008,0.008,0.014)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.07,0.07,0.09)
	e.ambient_light_energy = 0.65
	env.environment = e
	add_child(env)

	_make_box("Floor", Vector3(HOTEL_W, 0.2, HOTEL_D), Vector3(0,-0.1,0), Color(0.045,0.045,0.055))
	_make_wall(Vector3(HOTEL_W, 3.2, WALL_T), Vector3(0,1.6,-HOTEL_D/2), Color(0.08,0.075,0.075))
	_make_wall(Vector3(HOTEL_W, 3.2, WALL_T), Vector3(0,1.6,HOTEL_D/2), Color(0.08,0.075,0.075))
	_make_wall(Vector3(WALL_T, 3.2, HOTEL_D), Vector3(-HOTEL_W/2,1.6,0), Color(0.08,0.075,0.075))
	_make_wall(Vector3(WALL_T, 3.2, HOTEL_D), Vector3(HOTEL_W/2,1.6,0), Color(0.08,0.075,0.075))

	# Central corridor with two-ended stores on both sides.
	for z in range(-30, 31, 10):
		_make_store_pair(float(z))
	_make_wall(Vector3(WALL_T,3.2,60), Vector3(0,1.6,0), Color(0.07,0.065,0.07))
	# Door gaps through the center wall.
	for z in range(-30, 31, 10):
		_make_door_gap(z)

	# Roof staircase/elevator zone.
	_make_box("RoofStairs", Vector3(8,3,8), Vector3(0,1.5,31), Color(0.12,0.1,0.1))
	var heli := _make_box("HelicopterPad", Vector3(16,0.3,16), Vector3(0,3.1,32), Color(0.09,0.11,0.10))
	_lookish_mark(heli, "H")

func _make_store_pair(z: float) -> void:
	stores.append({"z": z})
	var side := 10.5
	var len := 9.4
	# left store outer walls
	_make_wall(Vector3(WALL_T,3.0,len), Vector3(-HOTEL_W/2 + 11.5,1.5,z), Color(0.10,0.08,0.08))
	_make_wall(Vector3(10.0,3.0,WALL_T), Vector3(-HOTEL_W/2 + 6.5,1.5,z-len/2), Color(0.10,0.08,0.08))
	_make_wall(Vector3(10.0,3.0,WALL_T), Vector3(-HOTEL_W/2 + 6.5,1.5,z+len/2), Color(0.10,0.08,0.08))
	# right store outer walls
	_make_wall(Vector3(WALL_T,3.0,len), Vector3(HOTEL_W/2 - 11.5,1.5,z), Color(0.10,0.08,0.08))
	_make_wall(Vector3(10.0,3.0,WALL_T), Vector3(HOTEL_W/2 - 6.5,1.5,z-len/2), Color(0.10,0.08,0.08))
	_make_wall(Vector3(10.0,3.0,WALL_T), Vector3(HOTEL_W/2 - 6.5,1.5,z+len/2), Color(0.10,0.08,0.08))
	# shelves
	for x in [-17.0,-13.5]:
		_make_box("Shelf", Vector3(1.1,1.2,5.8), Vector3(x,0.6,z), Color(0.12,0.09,0.08))
	for x in [17.0,13.5]:
		_make_box("Shelf", Vector3(1.1,1.2,5.8), Vector3(x,0.6,z), Color(0.12,0.09,0.08))

func _make_door_gap(z: int) -> void:
	# Decorative door frames at both ends of each store.
	_make_box("DoorFrameL", Vector3(2.2,2.5,0.25), Vector3(-18.5,1.25,z), Color(0.20,0.15,0.12))
	_make_box("DoorFrameR", Vector3(2.2,2.5,0.25), Vector3(18.5,1.25,z), Color(0.20,0.15,0.12))

func _make_wall(size: Vector3, pos: Vector3, color: Color) -> Node3D:
	return _make_static_box("Wall", size, pos, color)

func _make_box(n: String, size: Vector3, pos: Vector3, color: Color) -> Node3D:
	return _make_static_box(n, size, pos, color)

func _make_static_box(n: String, size: Vector3, pos: Vector3, color: Color) -> Node3D:
	var body := StaticBody3D.new()
	body.name = n
	body.position = pos
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	mesh.mesh = box
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.95
	mesh.material_override = mat
	body.add_child(mesh)
	var shape := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	shape.shape = bs
	body.add_child(shape)
	add_child(body)
	return body

func _lookish_mark(parent: Node3D, text: String) -> void:
	var label := Label3D.new()
	label.text = text
	label.font_size = 96
	label.modulate = Color(0.85,0.85,0.88)
	label.position = Vector3(0,0.25,0)
	parent.add_child(label)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.position = Vector3(0,1.0,24)
	add_child(player)
	var capsule := CollisionShape3D.new()
	var cs := CapsuleShape3D.new()
	cs.radius = 0.35
	cs.height = 1.5
	capsule.shape = cs
	capsule.position.y = 0.75
	player.add_child(capsule)

	var head := Node3D.new()
	player.add_child(head)
	camera = Camera3D.new()
	camera.position = Vector3(0,0.65,0)
	camera.current = true
	head.add_child(camera)
	flashlight = SpotLight3D.new()
	flashlight.light_energy = 3.2
	flashlight.spot_range = 18
	flashlight.spot_angle = 34
	flashlight.shadow_enabled = true
	camera.add_child(flashlight)
	yaw = PI
	_apply_camera_rotation()

func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)
	var panel := ColorRect.new()
	panel.position = Vector2(20,20)
	panel.size = Vector2(460,112)
	panel.color = Color(0.015,0.015,0.02,0.80)
	ui.add_child(panel)

	objective_label = Label.new()
	objective_label.position = Vector2(18,10)
	objective_label.size = Vector2(430,55)
	objective_label.text = objective
	objective_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	objective_label.add_theme_font_size_override("font_size",18)
	panel.add_child(objective_label)

	status_label = Label.new()
	status_label.position = Vector2(18,68)
	status_label.text = "Parts: 0/6    HP: 100    Stamina: 100"
	status_label.add_theme_font_size_override("font_size",16)
	panel.add_child(status_label)

	joystick_base = ColorRect.new()
	joystick_base.position = Vector2(36, get_viewport().size.y - 210)
	joystick_base.size = Vector2(150,150)
	joystick_base.color = Color(0.2,0.2,0.24,0.45)
	ui.add_child(joystick_base)
	joystick_knob = ColorRect.new()
	joystick_knob.size = Vector2(66,66)
	joystick_knob.color = Color(0.55,0.55,0.60,0.75)
	ui.add_child(joystick_knob)
	_update_joystick(Vector2.ZERO)

	interact_button = Button.new()
	interact_button.text = "INTERACT"
	interact_button.size = Vector2(170,80)
	interact_button.position = Vector2(get_viewport().size.x-210, get_viewport().size.y-190)
	interact_button.add_theme_font_size_override("font_size",22)
	interact_button.pressed.connect(_do_interact)
	ui.add_child(interact_button)

	sprint_button = Button.new()
	sprint_button.text = "RUN"
	sprint_button.toggle_mode = true
	sprint_button.size = Vector2(130,70)
	sprint_button.position = Vector2(get_viewport().size.x-160, get_viewport().size.y-285)
	sprint_button.add_theme_font_size_override("font_size",20)
	ui.add_child(sprint_button)

func _spawn_items() -> void:
	var positions := [
		Vector3(-15,0.65,-25), Vector3(15,0.65,-15),
		Vector3(-15,0.65,-5), Vector3(15,0.65,5),
		Vector3(-15,0.65,15), Vector3(15,0.65,25)
	]
	for i in positions.size():
		var n := _make_item("HeliPart%d" % (i+1), positions[i], Color(0.75,0.68,0.16))
		items.append({"node":n,"taken":false,"pos":positions[i]})

	# meat and toy
	var meat := _make_item("Meat", Vector3(-10,0.35,-30), Color(0.60,0.13,0.12))
	items.append({"node":meat,"taken":false,"kind":"meat"})
	var toy := _make_item("Toy", Vector3(10,0.45,30), Color(0.22,0.50,0.88))
	items.append({"node":toy,"taken":false,"kind":"toy"})
	var box := _make_item("ToyBox", Vector3(0,0.45,15), Color(0.35,0.18,0.08))
	items.append({"node":box,"taken":false,"kind":"toybox"})

func _make_item(n: String, pos: Vector3, color: Color) -> Node3D:
	var m := MeshInstance3D.new()
	m.name = n
	var box := BoxMesh.new()
	box.size = Vector3(0.7,0.7,0.7)
	m.mesh = box
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color * 0.3
	m.material_override = mat
	m.position = pos
	add_child(m)
	return m

func _spawn_monsters() -> void:
	# type, position, active
	_add_monster("Follower", Vector3(0,1,-26))
	_add_monster("Stare Beast", Vector3(-16,0.6,-6))
	_add_monster("Hungry Zombie", Vector3(-20,1,-5))
	_add_monster("Warning Animal", Vector3(19,0.7,8))
	_add_monster("Black-Dress Girl", Vector3(20,1,22))
	_add_monster("Toy Girl", Vector3(5,1,14))
	_add_monster("Crying Mouth", Vector3(-20,1,18))
	_add_monster("Room Between", Vector3(0,1,-34))

func _add_monster(kind: String, pos: Vector3) -> void:
	var body := CharacterBody3D.new()
	body.name = kind
	body.position = pos
	var col := CollisionShape3D.new()
	var cs := CapsuleShape3D.new()
	cs.radius = 0.45
	cs.height = 1.6
	col.shape = cs
	col.position.y = 0.8
	body.add_child(col)
	var mesh := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.5
	cm.height = 1.8
	mesh.mesh = cm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.16,0.16,0.18)
	if kind == "Crying Mouth":
		mat.albedo_color = Color(0.78,0.76,0.74)
		mat.emission_enabled = true
		mat.emission = Color(0.17,0.0,0.0)
	elif kind == "Black-Dress Girl":
		mat.albedo_color = Color(0.015,0.015,0.02)
	elif kind == "Warning Animal":
		mat.albedo_color = Color(0.13,0.25,0.12)
	mesh.material_override = mat
	body.add_child(mesh)
	add_child(body)
	monsters.append({"kind":kind,"node":body,"cooldown":0.0,"warned":false,"frozen":false})

func _update_monsters(delta: float) -> void:
	for m in monsters:
		var n: CharacterBody3D = m.node
		if not is_instance_valid(n):
			continue
		m.cooldown = maxf(0.0, m.cooldown - delta)
		var to_p := player.global_position - n.global_position
		var dist := to_p.length()
		var dir := to_p.normalized()
		match m.kind:
			"Follower":
				if dist < 11 and _player_looking_at(n, 0.94):
					m.frozen = true
				elif m.frozen and dist > 3:
					m.frozen = false
				if not m.frozen:
					n.velocity = dir * 1.45
				else:
					n.velocity = Vector3.ZERO
			"Stare Beast":
				n.velocity = Vector3.ZERO
				if dist < 8 and _player_looking_at(n, 0.88):
					if _player_looking_seconds(n) > 1.8:
						_damage_player(999, "The Stare Beast caught your eyes.")
			"Hungry Zombie":
				n.velocity = Vector3.ZERO
				if dist < 2.0 and not _has_item_kind("meat"):
					_damage_player(999, "The Hungry Zombie wanted meat.")
			"Warning Animal":
				n.velocity = Vector3.ZERO
				if dist < 12 and not m.warned:
					m.warned = true
					_show_message("UNKNOWN: If you watch your back, you will die.", 6.0)
			"Black-Dress Girl":
				if dist < 18:
					var safe := _near_emergency_light()
					n.velocity = Vector3.ZERO if safe else dir * 2.2
					if dist < 1.6 and not safe:
						_damage_player(35, "The Black-Dress Girl found you.")
			"Toy Girl":
				n.velocity = Vector3.ZERO
				if _has_item_kind("toy") and dist < 3.5:
					_show_message("Toy Girl: Put it in the box.", 3.0)
					if _near_item_kind("toybox") and _distance_to_item_kind("toybox") < 2:
						_take_item_kind("toy")
						_show_message("Toy Girl: Part 5 is near the north stairwell.", 5.0)
					elif dist < 1.2:
						_damage_player(20, "She grabbed your arm.")
			"Crying Mouth":
				var music_safe := _near_any_music_box()
				n.velocity = Vector3.ZERO if music_safe else dir * (2.9 if dist < 14 else 0.7)
				if dist < 1.5 and not music_safe:
					_damage_player(999, "The Crying Mouth swallowed the hall.")
			"Room Between":
				if dist < 9:
					n.velocity = dir * 2.0
					if dist < 1.4:
						_damage_player(999, "You were lost inside Room 000.")

func _update_items() -> void:
	interact_target = null
	var best := 2.2
	for it in items:
		if it.taken:
			continue
		var n: Node3D = it.node
		if not is_instance_valid(n):
			continue
		var d := player.global_position.distance_to(n.global_position)
		if d < best:
			best = d
			interact_target = it

func _do_interact() -> void:
	if interact_target == null:
		return
	var it := interact_target
	var n: Node3D = it.node
	if not is_instance_valid(n):
		return
	if it.has("kind") and it.kind == "meat":
		it.taken = true
		n.visible = false
		_show_message("You found MEAT. Give it to the Hungry Zombie.", 4)
		return
	if it.has("kind") and it.kind == "toy":
		it.taken = true
		n.visible = false
		_show_message("Toy collected. Find the box.", 4)
		return
	if it.has("kind") and it.kind == "toybox":
		if _has_item_kind("toy"):
			_take_item_kind("toy")
			_show_message("The Toy Girl whispers: the next part is near the north stairwell.", 5)
		else:
			_show_message("Something is missing from the box.", 3)
		return
	if n.name.begins_with("HeliPart"):
		it.taken = true
		n.visible = false
		helicopter_parts += 1
		objective = "Helicopter parts: %d/6. Reach the roof when all are found." % helicopter_parts
		_show_message("Helicopter part collected.", 2.5)

func _update_ui() -> void:
	status_label.text = "Parts: %d/6    HP: %d    Stamina: %d" % [helicopter_parts, int(health), int(stamina)]
	objective_label.text = objective
	interact_button.disabled = interact_target == null
	interact_button.text = "INTERACT" if interact_target == null else "USE / PICK UP"

func _update_lighting() -> void:
	flashlight.light_energy = 3.0 + sin(horror_clock * 3.0) * 0.18
	if int(horror_clock) % 17 == 0 and horror_clock > 5:
		flashlight.light_energy *= 0.7

func _damage_player(amount: float, reason: String) -> void:
	if message_clock > 0 and amount < 999:
		return
	health -= amount
	_show_message(reason, 3.0)
	if health <= 0:
		health = 100
	helicopter_parts = maxi(0, helicopter_parts - 1)
	_show_message("YOU DIED. One helicopter part was lost.", 4.0)
	_reset_player()

func _reset_player() -> void:
	player.global_position = Vector3(0,1,24)
	stamina = 100
	yaw = PI
	pitch = -0.08
	_apply_camera_rotation()

func _show_message(text: String, duration: float) -> void:
	objective = text
	message_clock = duration

func _has_item_kind(kind: String) -> bool:
	for it in items:
		if it.taken:
			continue
		if it.has("kind") and it.kind == kind:
			return true
	return false

func _take_item_kind(kind: String) -> void:
	for it in items:
		if it.taken:
			continue
		if it.has("kind") and it.kind == kind:
			it.taken = true
			var n: Node3D = it.node
			if is_instance_valid(n):
				n.visible = false
			return

func _distance_to_item_kind(kind: String) -> float:
	var best := 9999.0
	for it in items:
		if it.taken or not it.has("kind") or it.kind != kind:
			continue
		var n: Node3D = it.node
		if is_instance_valid(n):
			best = minf(best, player.global_position.distance_to(n.global_position))
	return best

func _near_item_kind(kind: String) -> bool:
	return _distance_to_item_kind(kind) < 2.0

func _near_any_music_box() -> bool:
	# Prototype safe zone: near the blue toy box acts as a temporary music box.
	return _distance_to_item_kind("toybox") < 3.2

func _near_emergency_light() -> bool:
	# Emergency lights are represented by the two glowing ends of the main hall.
	return absf(player.global_position.x) > 17.0 and absf(player.global_position.z) < 35.0

func _player_looking_at(target: Node3D, threshold: float) -> bool:
	var forward := -camera.global_transform.basis.z.normalized()
	var to_target := (target.global_position + Vector3.UP*0.7 - camera.global_position).normalized()
	return forward.dot(to_target) > threshold

func _player_looking_seconds(_target: Node3D) -> float:
	return horror_clock - floor(horror_clock / 3.0) * 3.0

