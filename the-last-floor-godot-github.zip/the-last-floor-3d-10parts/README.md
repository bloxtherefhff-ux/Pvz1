# The Last Floor — 3D Hotel / 10 Parts

This package contains the GitHub Actions build workflow for the Android 3D prototype.

## Build

1. Put `.github/workflows/build-apk.yml` in the repository.
2. Commit it to `main`.
3. Open GitHub Actions and run **Build The Last Floor 3D APK - 10 Parts**.
4. Download the `The-Last-Floor-3D-APK` artifact.

## Current prototype

- 3D OpenGL ES hotel
- 5 selectable floors
- 5 different monsters
- 3D player character
- 10 helicopter parts per floor
- Exit stays locked until all 10 parts are collected
- STUN: 3 seconds active, 15 seconds cooldown
- Android API 36 / JDK 17 / Gradle 9.6 / AGP 9.4
