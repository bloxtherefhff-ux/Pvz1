import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

/* ============================================================
   SKYLINE HOTEL – 10 FLOORS + ROOF
   First-person exploration, collect helicopter parts
   No monsters yet – pure atmosphere + characters
   ============================================================ */

const CONFIG = {
  floors: 10,
  floorHeight: 4.2,
  corridorWidth: 6,
  corridorLength: 28,
  roomDepth: 8,
  wallColor: 0x2a2420,
  floorColor: 0x1a1614,
  ceilingColor: 0x12100e,
  accent: 0x8b0000,
  gold: 0xc9a86c
};

// ---------- State ----------
let scene, camera, renderer, controls;
let player = { height: 1.7, speed: 4.8, velocity: new THREE.Vector3() };
let currentFloor = 1;
let partsCollected = 0;
const TOTAL_PARTS = 6;
let moveForward = false, moveBackward = false, moveLeft = false, moveRight = false;
let isMobile = false;
let joyAxis = { x: 0, y: 0 };
let lookDelta = { x: 0, y: 0 };
let interactables = [];
let npcs = [];
let parts = [];
let clock = new THREE.Clock();
let raycaster = new THREE.Raycaster();
let elevatorCooldown = 0;

// ---------- DOM ----------
const loadingEl = document.getElementById('loading');
const progressEl = document.getElementById('progress');
const hud = document.getElementById('hud');
const floorInd = document.getElementById('floor-indicator');
const partsEl = document.getElementById('parts');
const mobileControls = document.getElementById('mobile-controls');
const dialogue = document.getElementById('dialogue');
const npcNameEl = document.getElementById('npc-name');
const npcTextEl = document.getElementById('npc-text');
const winScreen = document.getElementById('win-screen');

// ---------- Init ----------
async function init() {
  isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || window.innerWidth < 900;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x050505);
  scene.fog = new THREE.FogExp2(0x050505, 0.035);

  camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 80);
  camera.position.set(0, player.height, 10);

  renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  document.body.appendChild(renderer.domElement);

  // Lights
  const ambient = new THREE.AmbientLight(0x404040, 0.45);
  scene.add(ambient);

  const hemi = new THREE.HemisphereLight(0x887766, 0x111111, 0.5);
  scene.add(hemi);

  // Build hotel
  buildHotel();

  // Player controls
  if (!isMobile) {
    controls = new PointerLockControls(camera, document.body);
    scene.add(controls.getObject());
    document.body.addEventListener('click', () => {
      if (!dialogue.classList.contains('hidden') || !winScreen.classList.contains('hidden')) return;
      controls.lock();
    });
  } else {
    // Mobile: free look via touch on right side
    setupMobileControls();
  }

  setupKeyboard();
  setupUI();

  // Hide loading
  progressEl.style.width = '100%';
  setTimeout(() => {
    loadingEl.classList.add('hidden');
    hud.classList.remove('hidden');
    if (isMobile) mobileControls.classList.remove('hidden');
  }, 600);

  window.addEventListener('resize', onResize);
  animate();
}

// ---------- Hotel Construction ----------
function buildHotel() {
  const group = new THREE.Group();
  group.name = 'Hotel';

  // Materials
  const wallMat = new THREE.MeshStandardMaterial({ color: CONFIG.wallColor, roughness: 0.85 });
  const floorMat = new THREE.MeshStandardMaterial({ color: CONFIG.floorColor, roughness: 0.9 });
  const ceilingMat = new THREE.MeshStandardMaterial({ color: CONFIG.ceilingColor, roughness: 1 });
  const carpetMat = new THREE.MeshStandardMaterial({ color: 0x3a1a1a, roughness: 0.95 });
  const woodMat = new THREE.MeshStandardMaterial({ color: 0x4a3525, roughness: 0.7 });
  const goldMat = new THREE.MeshStandardMaterial({ color: CONFIG.gold, metalness: 0.6, roughness: 0.35 });
  const redMat = new THREE.MeshStandardMaterial({ color: CONFIG.accent, roughness: 0.6 });

  // Ground floor + 9 more = 10 floors, then roof
  for (let f = 1; f <= CONFIG.floors; f++) {
    const y = (f - 1) * CONFIG.floorHeight;
    const floorGroup = new THREE.Group();
    floorGroup.name = `Floor${f}`;
    floorGroup.position.y = y;

    // Floor slab
    const slab = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 16, 0.25, CONFIG.corridorWidth + CONFIG.roomDepth * 2 + 4),
      floorMat
    );
    slab.position.set(0, -0.125, 0);
    slab.receiveShadow = true;
    floorGroup.add(slab);

    // Carpet runner
    const carpet = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength - 2, 0.02, 2.2),
      carpetMat
    );
    carpet.position.set(0, 0.01, 0);
    floorGroup.add(carpet);

    // Ceiling
    const ceil = new THREE.Mesh(
      new THREE.BoxGeometry(CONFIG.corridorLength + 16, 0.2, CONFIG.corridorWidth + CONFIG.roomDepth * 2 + 4),
      ceilingMat
    );
    ceil.position.set(0, CONFIG.floorHeight - 0.1, 0);
    floorGroup.add(ceil);

    // Long corridor walls (left & right)
    const wallH = CONFIG.floorHeight - 0.3;
    const longWallGeo = new THREE.BoxGeometry(CONFIG.corridorLength + 2, wallH, 0.3);

    // North wall (with room openings)
    const nWall = new THREE.Mesh(longWallGeo, wallMat);
    nWall.position.set(0, wallH / 2, -CONFIG.corridorWidth / 2);
    floorGroup.add(nWall);

    // South wall
    const sWall = new THREE.Mesh(longWallGeo, wallMat);
    sWall.position.set(0, wallH / 2, CONFIG.corridorWidth / 2);
    floorGroup.add(sWall);

    // End walls (east & west) – doors here
    const endWallGeo = new THREE.BoxGeometry(0.3, wallH, CONFIG.corridorWidth + 1);
    const eWall = new THREE.Mesh(endWallGeo, wallMat);
    eWall.position.set(CONFIG.corridorLength / 2 + 0.5, wallH / 2, 0);
    floorGroup.add(eWall);

    const wWall = new THREE.Mesh(endWallGeo, wallMat);
    wWall.position.set(-CONFIG.corridorLength / 2 - 0.5, wallH / 2, 0);
    floorGroup.add(wWall);

    // Simple room stubs on both sides (visual only)
    for (let i = -2; i <= 2; i++) {
      if (i === 0) continue;
      const roomZ = i > 0 ? CONFIG.corridorWidth / 2 + CONFIG.roomDepth / 2 : -CONFIG.corridorWidth / 2 - CONFIG.roomDepth / 2;
      const room = new THREE.Mesh(
        new THREE.BoxGeometry(5.5, wallH - 0.2, CONFIG.roomDepth - 0.5),
        wallMat
      );
      room.position.set(i * 5.5, wallH / 2 - 0.1, roomZ);
      floorGroup.add(room);

      // Door frame hint
      const door = new THREE.Mesh(
        new THREE.BoxGeometry(1.4, 2.4, 0.15),
        woodMat
      );
      door.position.set(i * 5.5, 1.2, i > 0 ? CONFIG.corridorWidth / 2 - 0.1 : -CONFIG.corridorWidth / 2 + 0.1);
      floorGroup.add(door);
    }

    // Dim wall lights every few meters
    for (let lx = -10; lx <= 10; lx += 7) {
      const light = new THREE.PointLight(0xffcc88, 0.55, 9, 1.5);
      light.position.set(lx, 2.6, 0);
      light.castShadow = false;
      floorGroup.add(light);

      // Light fixture
      const fixture = new THREE.Mesh(
        new THREE.CylinderGeometry(0.15, 0.2, 0.12, 8),
        goldMat
      );
      fixture.position.set(lx, 3.5, 0);
      floorGroup.add(fixture);
    }

    // Elevator / stair doors at both ends
    createElevatorDoor(floorGroup, CONFIG.corridorLength / 2 - 0.2, f, 'east');
    createElevatorDoor(floorGroup, -CONFIG.corridorLength / 2 + 0.2, f, 'west');

    // Floor number plaque
    const plaque = new THREE.Mesh(
      new THREE.PlaneGeometry(1.2, 0.5),
      new THREE.MeshBasicMaterial({ color: 0x222222 })
    );
    plaque.position.set(0, 2.2, -CONFIG.corridorWidth / 2 + 0.16);
    floorGroup.add(plaque);

    group.add(floorGroup);
  }

  // Roof
  const roofY = CONFIG.floors * CONFIG.floorHeight;
  const roof = new THREE.Group();
  roof.position.y = roofY;

  const roofSlab = new THREE.Mesh(
    new THREE.BoxGeometry(40, 0.4, 30),
    new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.8 })
  );
  roofSlab.position.y = 0.2;
  roof.add(roofSlab);

  // Helipad
  const pad = new THREE.Mesh(
    new THREE.CylinderGeometry(5.5, 5.5, 0.15, 32),
    new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.6 })
  );
  pad.position.set(0, 0.35, 0);
  roof.add(pad);

  const padMark = new THREE.Mesh(
    new THREE.RingGeometry(4.2, 4.6, 32),
    new THREE.MeshBasicMaterial({ color: 0xc9a86c, side: THREE.DoubleSide })
  );
  padMark.rotation.x = -Math.PI / 2;
  padMark.position.y = 0.43;
  roof.add(padMark);

  // Simple helicopter silhouette (non-functional yet)
  const heli = createHelicopter();
  heli.position.set(0, 1.8, 0);
  roof.add(heli);

  // Roof lights
  const roofLight = new THREE.PointLight(0xffeedd, 1.2, 25);
  roofLight.position.set(0, 6, 0);
  roof.add(roofLight);

  // Night sky box simple
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(70, 16, 12),
    new THREE.MeshBasicMaterial({ color: 0x020208, side: THREE.BackSide })
  );
  sky.position.y = roofY;
  scene.add(sky);

  group.add(roof);
  scene.add(group);

  // Place characters & parts
  placeCharacters();
  placeParts();
}

function createElevatorDoor(parent, x, floorNum, side) {
  const mat = new THREE.MeshStandardMaterial({ color: 0x333333, metalness: 0.4, roughness: 0.5 });
  const door = new THREE.Mesh(new THREE.BoxGeometry(0.15, 2.6, 1.8), mat);
  door.position.set(x, 1.3, 0);
  door.userData = { type: 'elevator', floor: floorNum, side };
  parent.add(door);

  // Call button
  const btn = new THREE.Mesh(
    new THREE.BoxGeometry(0.12, 0.35, 0.12),
    new THREE.MeshStandardMaterial({ color: 0xc9a86c })
  );
  btn.position.set(x + (side === 'east' ? -0.25 : 0.25), 1.3, 1.1);
  btn.userData = { type: 'elevator-btn', floor: floorNum };
  parent.add(btn);
  interactables.push(btn);
}

function createHelicopter() {
  const g = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2a2a2a, metalness: 0.5, roughness: 0.4 });
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.9, 2.2, 4, 12), bodyMat);
  body.rotation.z = Math.PI / 2;
  g.add(body);

  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.25, 2.8, 8), bodyMat);
  tail.rotation.z = Math.PI / 2;
  tail.position.set(-2.5, 0.2, 0);
  g.add(tail);

  const rotor = new THREE.Mesh(
    new THREE.BoxGeometry(6.5, 0.08, 0.35),
    new THREE.MeshStandardMaterial({ color: 0x111111 })
  );
  rotor.position.y = 1.1;
  g.add(rotor);

  // Missing parts visual – will light up as collected
  g.userData.missing = true;
  return g;
}

// ---------- Characters ----------
function placeCharacters() {
  const charData = [
    { name: "Mr. Aldridge", floor: 1, pos: [6, 0, 1.8], lines: [
      "Welcome to the Skyline… or what's left of it.",
      "The elevators still work, but the upper floors feel wrong.",
      "I used to manage this place. Now I just wait."
    ]},
    { name: "Lena Voss", floor: 3, pos: [-8, 0, -1.5], lines: [
      "You're looking for helicopter parts, aren't you?",
      "I saw one near the old laundry chute on floor 5.",
      "Don't stay too long on any floor after midnight."
    ]},
    { name: "Old Theo", floor: 5, pos: [4, 0, 1.6], lines: [
      "The roof is the only way out now.",
      "I fixed the radio once… but the blades need work.",
      "Something lives between the walls. You'll hear it later."
    ]},
    { name: "Nurse Maren", floor: 7, pos: [-5, 0, -1.8], lines: [
      "This used to be a recovery wing.",
      "Patients left, but the rooms kept their memories.",
      "Check the supply closet on floor 9 – I left a toolbox."
    ]},
    { name: "Rook", floor: 9, pos: [9, 0, 1.4], lines: [
      "Almost at the top. Good.",
      "The last part is usually on the roof itself… or just below.",
      "When the helicopter is ready, leave. Don't look back."
    ]},
    { name: "The Night Clerk", floor: 2, pos: [-3, 0, 1.7], lines: [
      "Front desk is closed. Permanently.",
      "Keys don't open the right doors anymore.",
      "Keep moving upward. That's the only rule that still works."
    ]}
  ];

  charData.forEach(c => {
    const npc = createNPC(c.name);
    const y = (c.floor - 1) * CONFIG.floorHeight;
    npc.position.set(c.pos[0], y, c.pos[2]);
    npc.userData = {
      type: 'npc',
      name: c.name,
      lines: c.lines,
      lineIndex: 0,
      floor: c.floor
    };
    scene.add(npc);
    npcs.push(npc);
    interactables.push(npc);
  });
}

function createNPC(name) {
  const g = new THREE.Group();

  // Body
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.35, 0.9, 4, 8),
    new THREE.MeshStandardMaterial({ color: 0x3a3030, roughness: 0.8 })
  );
  body.position.y = 1.1;
  g.add(body);

  // Head
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.28, 12, 10),
    new THREE.MeshStandardMaterial({ color: 0xc4a484, roughness: 0.7 })
  );
  head.position.y = 1.85;
  g.add(head);

  // Simple coat / shoulders
  const coat = new THREE.Mesh(
    new THREE.BoxGeometry(0.85, 0.7, 0.45),
    new THREE.MeshStandardMaterial({ color: 0x1f1818 })
  );
  coat.position.y = 1.35;
  g.add(coat);

  // Name label (sprite-like)
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.fillStyle = '#c9a86c';
  ctx.font = 'bold 28px system-ui';
  ctx.textAlign = 'center';
  ctx.fillText(name, 128, 42);
  const tex = new THREE.CanvasTexture(canvas);
  const label = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
  label.scale.set(1.8, 0.45, 1);
  label.position.y = 2.4;
  g.add(label);

  g.castShadow = true;
  return g;
}

// ---------- Collectible Parts ----------
function placeParts() {
  const locations = [
    { floor: 1, pos: [10, 0.4, -1.5] },
    { floor: 3, pos: [-11, 0.4, 1.2] },
    { floor: 4, pos: [2, 0.4, -2] },
    { floor: 6, pos: [-7, 0.4, 1.8] },
    { floor: 8, pos: [8, 0.4, -1.6] },
    { floor: 10, pos: [0, 0.5, 3] }   // near roof access
  ];

  locations.forEach((loc, i) => {
    const part = createPart(i);
    const y = (loc.floor - 1) * CONFIG.floorHeight;
    part.position.set(loc.pos[0], y + loc.pos[1], loc.pos[2]);
    part.userData = { type: 'part', id: i, collected: false };
    scene.add(part);
    parts.push(part);
    interactables.push(part);
  });
}

function createPart(id) {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({
    color: 0xc9a86c,
    metalness: 0.7,
    roughness: 0.3,
    emissive: 0x3a2a10,
    emissiveIntensity: 0.3
  });

  // Different shapes for variety
  let mesh;
  if (id % 3 === 0) mesh = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.35, 0.5), mat);
  else if (id % 3 === 1) mesh = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.6, 10), mat);
  else mesh = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.1, 8, 16), mat);

  mesh.castShadow = true;
  g.add(mesh);

  // Glow
  const light = new THREE.PointLight(0xc9a86c, 0.6, 3);
  light.position.y = 0.3;
  g.add(light);

  return g;
}

// ---------- Controls ----------
function setupKeyboard() {
  const onKey = (e, pressed) => {
    switch (e.code) {
      case 'KeyW': case 'ArrowUp': moveForward = pressed; break;
      case 'KeyS': case 'ArrowDown': moveBackward = pressed; break;
      case 'KeyA': case 'ArrowLeft': moveLeft = pressed; break;
      case 'KeyD': case 'ArrowRight': moveRight = pressed; break;
      case 'KeyE': case 'Space': if (pressed) tryInteract(); break;
    }
  };
  document.addEventListener('keydown', e => onKey(e, true));
  document.addEventListener('keyup', e => onKey(e, false));
}

function setupMobileControls() {
  const base = document.getElementById('joystick-base');
  const stick = document.getElementById('joystick-stick');
  const lookZone = document.getElementById('look-zone');
  const interactBtn = document.getElementById('interact-btn');

  let joyActive = false;
  let joyId = null;
  let lookId = null;
  let lastLook = { x: 0, y: 0 };

  // Joystick
  base.addEventListener('touchstart', e => {
    e.preventDefault();
    joyActive = true;
    joyId = e.changedTouches[0].identifier;
  }, { passive: false });

  window.addEventListener('touchmove', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        const rect = base.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        let dx = t.clientX - cx;
        let dy = t.clientY - cy;
        const max = rect.width / 2 - 10;
        const len = Math.sqrt(dx * dx + dy * dy);
        if (len > max) {
          dx = (dx / len) * max;
          dy = (dy / len) * max;
        }
        stick.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
        joyAxis.x = dx / max;
        joyAxis.y = -dy / max; // forward is negative screen y
      }
      if (t.identifier === lookId) {
        const dx = t.clientX - lastLook.x;
        const dy = t.clientY - lastLook.y;
        lookDelta.x += dx * 0.004;
        lookDelta.y += dy * 0.004;
        lastLook.x = t.clientX;
        lastLook.y = t.clientY;
      }
    }
  }, { passive: false });

  window.addEventListener('touchend', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) {
        joyActive = false;
        joyId = null;
        stick.style.transform = 'translate(-50%, -50%)';
        joyAxis.x = 0;
        joyAxis.y = 0;
      }
      if (t.identifier === lookId) lookId = null;
    }
  });

  // Look zone
  lookZone.addEventListener('touchstart', e => {
    e.preventDefault();
    lookId = e.changedTouches[0].identifier;
    lastLook.x = e.changedTouches[0].clientX;
    lastLook.y = e.changedTouches[0].clientY;
  }, { passive: false });

  interactBtn.addEventListener('touchstart', e => {
    e.preventDefault();
    tryInteract();
  }, { passive: false });
}

// ---------- Interaction ----------
function tryInteract() {
  if (!dialogue.classList.contains('hidden')) return;

  const origin = camera.getWorldPosition(new THREE.Vector3());
  const dir = camera.getWorldDirection(new THREE.Vector3());
  raycaster.set(origin, dir);
  raycaster.far = 3.2;

  const hits = raycaster.intersectObjects(interactables, true);
  if (hits.length === 0) return;

  let obj = hits[0].object;
  while (obj && !obj.userData.type) obj = obj.parent;
  if (!obj) return;

  const data = obj.userData;

  if (data.type === 'npc') {
    showDialogue(data.name, data.lines[data.lineIndex % data.lines.length]);
    data.lineIndex++;
  } else if (data.type === 'part' && !data.collected) {
    data.collected = true;
    partsCollected++;
    partsEl.textContent = `Parts: ${partsCollected} / ${TOTAL_PARTS}`;
    // Remove glow + mesh
    obj.visible = false;
    // Simple feedback
    if (partsCollected >= TOTAL_PARTS) {
      document.getElementById('objective').textContent = 'All parts found! Go to the roof.';
    }
  } else if (data.type === 'elevator' || data.type === 'elevator-btn') {
    useElevator(data.floor);
  }
}

function showDialogue(name, text) {
  npcNameEl.textContent = name;
  npcTextEl.textContent = text;
  dialogue.classList.remove('hidden');
  if (controls && controls.isLocked) controls.unlock();
}

document.getElementById('dialogue-close').addEventListener('click', () => {
  dialogue.classList.add('hidden');
});

function useElevator(fromFloor) {
  if (elevatorCooldown > 0) return;
  elevatorCooldown = 1.2;

  // Go up one floor. If on last floors and all parts collected → roof
  let next = fromFloor + 1;
  let goToRoof = false;

  if (partsCollected >= TOTAL_PARTS && fromFloor >= CONFIG.floors - 1) {
    goToRoof = true;
  } else if (next > CONFIG.floors) {
    next = 1; // wrap around if not ready for roof
  }

  const mover = isMobile || !controls ? camera : controls.getObject();

  if (goToRoof) {
    // Roof height
    mover.position.set(0, CONFIG.floors * CONFIG.floorHeight + player.height, 0);
    currentFloor = 'Roof';
    floorInd.textContent = 'Roof';
    checkWin();
  } else {
    const y = (next - 1) * CONFIG.floorHeight + player.height;
    mover.position.set(0, y, 6); // spawn a bit forward in the corridor
    currentFloor = next;
    floorInd.textContent = `Floor ${currentFloor}`;
  }
}

function checkWin() {
  if (partsCollected >= TOTAL_PARTS) {
    setTimeout(() => {
      winScreen.classList.remove('hidden');
      if (controls) controls.unlock();
    }, 800);
  }
}

document.getElementById('restart-btn').addEventListener('click', () => location.reload());

// ---------- Movement & Animation ----------
function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  elevatorCooldown = Math.max(0, elevatorCooldown - dt);

  // Movement
  const speed = player.speed * dt;
  const forward = new THREE.Vector3();
  const right = new THREE.Vector3();

  // Get the object we actually move
  const mover = isMobile ? camera : (controls ? controls.getObject() : camera);

  if (isMobile) {
    // Mobile look
    camera.rotation.order = 'YXZ';
    camera.rotation.y -= lookDelta.x;
    camera.rotation.x -= lookDelta.y;
    camera.rotation.x = Math.max(-1.2, Math.min(1.2, camera.rotation.x));
    lookDelta.x = 0;
    lookDelta.y = 0;

    camera.getWorldDirection(forward);
    forward.y = 0;
    forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();

    mover.position.addScaledVector(forward, joyAxis.y * speed);
    mover.position.addScaledVector(right, joyAxis.x * speed);
  } else if (controls && controls.isLocked) {
    controls.getDirection(forward);
    forward.y = 0;
    forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();

    if (moveForward) mover.position.addScaledVector(forward, speed);
    if (moveBackward) mover.position.addScaledVector(forward, -speed);
    if (moveLeft) mover.position.addScaledVector(right, -speed);
    if (moveRight) mover.position.addScaledVector(right, speed);
  }

  // ===== SIMPLE COLLISION / BOUNDS =====
  // Keep player inside the long corridor on every floor
  const halfLen = CONFIG.corridorLength / 2 - 0.8;   // leave a little room at ends
  const halfWidth = CONFIG.corridorWidth / 2 - 0.6;

  mover.position.x = Math.max(-halfLen, Math.min(halfLen, mover.position.x));
  mover.position.z = Math.max(-halfWidth, Math.min(halfWidth, mover.position.z));

  // Keep player on the correct floor height (no falling through)
  if (currentFloor !== 'Roof') {
    const targetY = (currentFloor - 1) * CONFIG.floorHeight + player.height;
    // Snap if too far, otherwise soft correct
    if (Math.abs(mover.position.y - targetY) > 2.5) {
      mover.position.y = targetY;
    } else {
      mover.position.y += (targetY - mover.position.y) * 0.25;
    }
  } else {
    // On roof – keep above the roof slab
    const roofY = CONFIG.floors * CONFIG.floorHeight + player.height;
    if (mover.position.y < roofY - 0.5) mover.position.y = roofY;
  }

  // Update current floor display from actual height
  if (currentFloor !== 'Roof') {
    const f = Math.floor(mover.position.y / CONFIG.floorHeight) + 1;
    if (f >= 1 && f <= CONFIG.floors && f !== currentFloor) {
      currentFloor = f;
      floorInd.textContent = `Floor ${currentFloor}`;
    }
  }

  // Gentle bob for parts
  parts.forEach(p => {
    if (!p.userData.collected) {
      p.rotation.y += dt * 1.2;
      p.position.y += Math.sin(clock.elapsedTime * 2 + p.userData.id) * 0.002;
    }
  });

  renderer.render(scene, camera);
}

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

function setupUI() {
  // progress fake
  let p = 0;
  const iv = setInterval(() => {
    p += 12;
    progressEl.style.width = Math.min(p, 90) + '%';
    if (p >= 90) clearInterval(iv);
  }, 80);
}

// Start
init().catch(console.error);
