# Skyline Hotel – Escape

A mobile-friendly 3D first-person exploration game.

## Current features
- **10 hotel floors** + roof with helipad & helicopter
- First-person controls (mouse + WASD on desktop, virtual joystick + touch look on mobile)
- **6 named characters** with dialogue
- **6 helicopter parts** to collect (scattered across floors)
- Elevators / floor transitions at both ends of each corridor
- Atmospheric lighting, fog, and hotel layout
- No monsters yet (ready for the next update)

## Characters
| Name            | Floor | Role                  |
|-----------------|-------|-----------------------|
| Mr. Aldridge    | 1     | Former manager        |
| The Night Clerk | 2     | Front desk            |
| Lena Voss       | 3     | Guest / survivor      |
| Old Theo        | 5     | Mechanic              |
| Nurse Maren     | 7     | Former staff          |
| Rook            | 9     | Guide near the top    |

## How to play
1. Open `index.html` in a modern browser (Chrome / Safari / Firefox).
2. **Desktop**: Click to lock mouse, WASD to move, E / Space to interact.
3. **Mobile**: Left joystick = move, right side of screen = look, red button = interact.
4. Talk to the characters, collect the glowing gold parts, use the elevators at either end of the corridor, reach the roof with all 6 parts.

## Build for stores / APK
Zip the entire `hotel-game` folder and feed it to the GitHub Action we created earlier (or use Capacitor / Cordova / PWABuilder).

```bash
cd hotel-game
zip -r ../skyline-hotel.zip .
```

Then upload the zip to the Action or host the folder as a PWA.
