# Skyline Hotel – Ready for GitHub

## How to use (super simple)

1. Create a new GitHub repository
2. Upload **everything** inside this folder to the repo root
   (or just upload `skyline-hotel-game.zip` + the `.github` folder)
3. Go to the **Actions** tab → select **Build Skyline Hotel App** → **Run workflow**
4. When it finishes, download the artifact called **SkylineHotel-App**
5. That folder is your complete mobile app (PWA + APK instructions)

### Updating the game later
- Make changes to the game
- Re-zip the `hotel-game` folder as **skyline-hotel-game.zip**
- Replace the zip in the repo
- Run the Action again

The Action always looks for the exact filename `skyline-hotel-game.zip`.
