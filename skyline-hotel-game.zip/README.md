# 🏨 SKYLINE HOTEL - Mobile Horror Game

A dark, intense mobile horror game built with Three.js. Collect helicopter parts, survive terrifying monsters, and escape alive.

## 🎮 Features

### Characters
- **FAT**: Spawns with free Totem of Undying + respawn on death
- **SHORT**: 1.5x speed multiplier
- **SKINNY**: Time Slow ability (slows all monsters to 40% speed)

### Gameplay
- 10 procedurally-different floors
- 5 unique monster types with AI behaviors
- Time management & resource collection
- Multiple difficulty levels

### Mobile Controls
- **Joystick**: Left side - movement
- **Drag**: Right side - look around
- **E Button**: Interact with doors/parts
- **Q Button**: Use gum (insta-kill weapon)
- **F Button**: Use ability (character-specific)

### Monsters
1. **Watcher** - Freezes when looked at, advances when not
2. **Gaze** - Staring too long = death (6 eyes, icosahedron head)
3. **Zombie** - Pure aggression
4. **Hunter** - Fast with sharp spikes
5. **Stalker** - Single magenta eye stalks you

## 📱 Deploy to GitHub Pages

1. **Create a new GitHub repo**
2. **Push this code:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/skyline-hotel.git
   git branch -M main
   git push -u origin main
   ```

3. **Enable GitHub Pages:**
   - Go to Settings → Pages
   - Source: `GitHub Actions`
   - Save

4. **Play:** Visit `https://YOUR_USERNAME.github.io/skyline-hotel/` 🎮

## 🛠️ Tech Stack
- Three.js r170 (WebGL 3D)
- Pure JavaScript (no build step needed)
- Mobile-optimized (touch-only, no keyboard)
- Flat-shading & minimal geometry for performance

## 🎯 Objective
- Collect 10 helicopter parts
- Survive floor 10
- Escape the roof alive

## 📊 Performance
- 60+ FPS on modern phones
- Optimized shadows & lighting
- Minimal draw calls
- Touch-responsive controls

---

**Made for mobile. Built to terrify.** 🏨👹
