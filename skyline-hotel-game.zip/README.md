# Skyline Hotel – Build Real APK

## What to upload to GitHub

Upload these two things to your repository root:

1. `skyline-hotel-game.zip`
2. The `.github` folder

## How to get the APK

1. Go to the **Actions** tab
2. Click **Build APK from skyline-hotel-game.zip**
3. Click **Run workflow**
4. Wait a few minutes
5. Download the artifact called **SkylineHotel-APK**
6. Install the `.apk` on your phone
