//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by LawnProject.rc
//
#define IDC_CURSOR1                     102
#define IDI_APP_ICON                    103

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
