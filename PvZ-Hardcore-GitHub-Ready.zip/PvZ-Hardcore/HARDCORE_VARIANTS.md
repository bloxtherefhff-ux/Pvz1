# PvZ Hardcore variants

Every plant definition receives a dedicated hardcore cost/recharge rebalance and a plant-specific health profile.

Regular wave zombies have a 15% base chance to become a hardcore variant, increasing by 5 percentage points per five completed waves and capping at 40%. Hardcore variants retain their original zombie type and AI, gain stronger stats, receive a unique tint, and each zombie class has a unique periodic ability.


## Zombie ability chance
Every spawned zombie has a 50% chance to become a Hardcore variant. Hardcore variants keep their original zombie type and AI, receive a type-specific color, and execute a unique ability for that zombie class. The boss also has its own pulse ability.

## v12 zombie ability pass
Hardcore-colored/special zombies now have distinct periodic abilities by type rather than receiving only generic stat buffs. Examples include ally rally, armor bash, charge, regeneration, dancer healing aura, water rush, sled armor, digger strike, gargantuar smash, boss command pulse, and distinct helper-head attacks.
